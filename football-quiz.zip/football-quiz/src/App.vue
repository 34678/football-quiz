<template>
  <div id="app">
 <router-view></router-view>
  
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>

</style>
<style  lang="scss" >
  #app {
      height: 100%;
      width: 100%;
      background-image: url('../static/images/bg.png');
        background-size: 100% 100%;
    background-repeat: no-repeat;
    background-position: center;
    background-color: #76a559;
  }
</style>

 