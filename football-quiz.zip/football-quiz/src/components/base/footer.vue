<template>
  <div class="footer">
      <img src="../../../static/images/qrcode.png">
      <img src="../../../static/images/gamename.png">
  </div>
</template>
<script>
export default {}
</script>
<style scoped lang="scss" >
.footer{
    height: 100px;
    width: 100px;
}
</style>
 