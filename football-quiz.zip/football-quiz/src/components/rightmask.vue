<template>
  <div class="rightmask">
      <img src="../../static/images/right.png">
  </div>
</template>
<script>
export default {}
</script>
<style scoped lang="scss" >
img{
        @include dpr(width, 277px);
        @include dpr(height, 182px);
            margin-top: 50%;
    margin-left: 13%;
}
</style>